</main><!-- #main -->
</div><!-- #primary -->
</div><!-- .col-full -->
</div><!-- #content -->
<div class='footer-width-fixer'>
    <div data-elementor-type="wp-post" data-elementor-id="3091" class="elementor elementor-3091" data-elementor-settings="[]">
        <div class="elementor-section-wrap">
            <div class="elementor-section elementor-top-section elementor-element elementor-element-af629fa elementor-section-content-middle elementor-section-stretched elementor-hidden-desktop elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="af629fa" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-06256c2" data-id="06256c2" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-82aa825 elementor-view-default elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="82aa825" data-element_type="widget" data-widget_type="icon-box.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-icon-box-wrapper">
                                        <div class="elementor-icon-box-icon">
                                            <a class="elementor-icon elementor-animation-" href="https://mainlandsolar.com/">
                                                <i aria-hidden="true" class="technocy-icon- technocy-icon-home"></i>				</a>
                                        </div>
                                        <div class="elementor-icon-box-content">
                                            <h3 class="elementor-icon-box-title">
                                                <a href="https://mainlandsolar.com/" >
                                                    Shop					</a>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-291ee15" data-id="291ee15" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-58e4f5e elementor-view-default elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="58e4f5e" data-element_type="widget" data-widget_type="icon-box.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-icon-box-wrapper">
                                        <div class="elementor-icon-box-icon">
                                            <a class="elementor-icon elementor-animation-" href="https://mainlandsolar.com/my-account/">
                                                <i aria-hidden="true" class="technocy-icon- technocy-icon-account"></i>				</a>
                                        </div>
                                        <div class="elementor-icon-box-content">
                                            <h3 class="elementor-icon-box-title">
                                                <a href="https://mainlandsolar.com/my-account/" >
                                                    My Account					</a>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-e818a93" data-id="e818a93" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-d024324 elementor-widget elementor-widget-technocy-search" data-id="d024324" data-element_type="widget" data-widget_type="technocy-search.default">
                                <div class="elementor-widget-container">
                                    <div class="site-header-search">
                                        <a href="#" class="button-search-popup">
                                            <i class="technocy-icon-search"></i>
                                            <span class="content">Search</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-e7d2a0c" data-id="e7d2a0c" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-0fb6fd0 elementor-view-default elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="0fb6fd0" data-element_type="widget" data-widget_type="icon-box.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-icon-box-wrapper">
                                        <div class="elementor-icon-box-icon">
                                            <a class="elementor-icon elementor-animation-" href="https://mainlandsolar.com/wishlist/">
                                                <i aria-hidden="true" class="far fa-heart"></i>				</a>
                                        </div>
                                        <div class="elementor-icon-box-content">
                                            <h3 class="elementor-icon-box-title">
                                                <a href="https://mainlandsolar.com/wishlist/" >
                                                    Wishlist					</a>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="elementor-section elementor-top-section elementor-element elementor-element-dd84fa0 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="dd84fa0" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ee9bddb" data-id="ee9bddb" data-element_type="column">
                        <div class="elementor-widget-wrap">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
    <div class='footer-width-fixer'>		<div data-elementor-type="wp-post" data-elementor-id="860" class="elementor elementor-860" data-elementor-settings="[]">
            <div class="elementor-section-wrap">
                <div class="elementor-section elementor-top-section elementor-element elementor-element-d52a876 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d52a876" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-container elementor-column-gap-no">
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-24cc772" data-id="24cc772" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-7ec7671 elementor-position-left elementor-vertical-align-middle elementor-view-default elementor-widget elementor-widget-icon-box" data-id="7ec7671" data-element_type="widget" data-widget_type="icon-box.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-icon-box-wrapper">
                                            <div class="elementor-icon-box-icon">
				<span class="elementor-icon elementor-animation-" >
				<i aria-hidden="true" class="technocy-icon- technocy-icon-mail-1"></i>				</span>
                                            </div>
                                            <div class="elementor-icon-box-content">
                                                <h3 class="elementor-icon-box-title">
					<span>
						Newsletter					</span>
                                                </h3>
                                                <p class="elementor-icon-box-description">
                                                    Get the latest deals, updates & more					</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-9cf4d58" data-id="9cf4d58" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-470c354 elementor-widget-mobile__width-initial elementor-widget elementor-widget-technocy-mailchmip" data-id="470c354" data-element_type="widget" data-widget_type="technocy-mailchmip.default">
                                    <div class="elementor-widget-container">
                                        <div class="form-style"><script>(function() {
                                                    window.mc4wp = window.mc4wp || {
                                                        listeners: [],
                                                        forms: {
                                                            on: function(evt, cb) {
                                                                window.mc4wp.listeners.push(
                                                                    {
                                                                        event   : evt,
                                                                        callback: cb
                                                                    }
                                                                );
                                                            }
                                                        }
                                                    }
                                                })();
                                            </script><!-- Mailchimp for WordPress v4.8.6 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-110" method="post" data-id="110" data-name="Mainlandsolar Mailchimp" ><div class="mc4wp-form-fields"><p class="form-input">
                                                        <input type="email" name="EMAIL" placeholder="Your email address" required />
                                                    </p>

                                                    <p>
                                                        <button type="submit" value="subscribe">Subscribe <span class="icon"><i aria-hidden="true" class="fas fa-chevron-right"></i></span>
                                                        </button>
                                                    </p>
                                                </div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1646248143" /><input type="hidden" name="_mc4wp_form_id" value="110" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /><div class="mc4wp-response"></div></form><!-- / Mailchimp for WordPress Plugin --></div>		</div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-7956df4" data-id="7956df4" data-element_type="column">
                            <div class="elementor-widget-wrap">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="elementor-section elementor-top-section elementor-element elementor-element-aa83f0f elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="aa83f0f" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-container elementor-column-gap-no">
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-d9232cf" data-id="d9232cf" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-8dd1b9f elementor-widget elementor-widget-heading" data-id="8dd1b9f" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <style>/*! elementor - v3.5.5 - 03-02-2022 */
                                            .elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h2 class="elementor-heading-title elementor-size-default">company</h2>		</div>
                                </div>
                                <div class="elementor-element elementor-element-1f788c9 elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="1f788c9" data-element_type="widget" data-widget_type="icon-list.default">
                                    <div class="elementor-widget-container">
                                        <ul class="elementor-icon-list-items">
                                            <li class="elementor-icon-list-item">
                                                <a href="https://mainlandsolar.com/about/">

                                                    <span class="elementor-icon-list-text">About Us</span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item">
                                                <a href="https://mainlandsolar.com/contact/">

                                                    <span class="elementor-icon-list-text">Contact Us</span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item">
                                                <a href="https://mainlandsolar.com/news-and-updates">

                                                    <span class="elementor-icon-list-text">News & Updates</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-22bbe8a" data-id="22bbe8a" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-7927521 elementor-widget elementor-widget-heading" data-id="7927521" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">help</h2>		</div>
                                </div>
                                <div class="elementor-element elementor-element-acf459e elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="acf459e" data-element_type="widget" data-widget_type="icon-list.default">
                                    <div class="elementor-widget-container">
                                        <ul class="elementor-icon-list-items">
                                            <li class="elementor-icon-list-item">
                                                <a href="https://mainlandsolar.com/privacy-policy">

                                                    <span class="elementor-icon-list-text">Privacy Policy</span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item">
                                                <a href="https://mainlandsolar.com/term-and-conditions">

                                                    <span class="elementor-icon-list-text">Terms & Conditions </span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-c17be82" data-id="c17be82" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-bf8e71a elementor-widget elementor-widget-heading" data-id="bf8e71a" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">my account</h2>		</div>
                                </div>
                                <div class="elementor-element elementor-element-c26c617 elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="c26c617" data-element_type="widget" data-widget_type="icon-list.default">
                                    <div class="elementor-widget-container">
                                        <ul class="elementor-icon-list-items">
                                            <li class="elementor-icon-list-item">
                                                <a href="https://mainlandsolar.com/my-account">

                                                    <span class="elementor-icon-list-text">My Profile</span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item">
                                                <a href="https://mainlandsolar.com/wishlist/">

                                                    <span class="elementor-icon-list-text">My Wish List</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-6906542" data-id="6906542" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-ad73280 elementor-widget elementor-widget-heading" data-id="ad73280" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">Contact info</h2>		</div>
                                </div>
                                <div class="elementor-element elementor-element-b8f204f elementor-widget elementor-widget-heading" data-id="b8f204f" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-heading-title elementor-size-default">09120330183 (Call or WhatsApp)</div>		</div>
                                </div>
                                <div class="elementor-element elementor-element-3af2b25 elementor-widget elementor-widget-text-editor" data-id="3af2b25" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <style>/*! elementor - v3.5.5 - 03-02-2022 */
                                            .elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap{background-color:#818a91;color:#fff}.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap{color:#818a91;border:3px solid;background-color:transparent}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap{margin-top:8px}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter{width:1em;height:1em}.elementor-widget-text-editor .elementor-drop-cap{float:left;text-align:center;line-height:1;font-size:50px}.elementor-widget-text-editor .elementor-drop-cap-letter{display:inline-block}</style>				<div>Mon To Sun: 09:00 AM To 6:00 PM</div>						</div>
                                </div>
                                <div class="elementor-element elementor-element-129cc52 elementor-widget__width-auto elementor-widget-mobile__width-auto elementor-widget elementor-widget-text-editor" data-id="129cc52" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <p><a href="mailto:support@mainlandsolar.com">support@mainlandsolar.com</a></p>						</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <section class="elementor-section elementor-top-section elementor-element elementor-element-cc4ec04 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="cc4ec04" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ab7d492" data-id="ab7d492" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-c4924de elementor-widget elementor-widget-text-editor" data-id="c4924de" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <p><span style="color: #000000;">Copyright © 2021 </span><a style="background-color: #ffffff;" href="https://mainlandsolar.com">Mainlandsolar</a><span style="color: #000000;">. All rights reserved</span></p>						</div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-9ed4dff" data-id="9ed4dff" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-bcfa558 elementor-icon-list--layout-inline elementor-tablet-align-right elementor-mobile-align-center elementor-align-right elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="bcfa558" data-element_type="widget" data-widget_type="icon-list.default">
                                    <div class="elementor-widget-container">
                                        <ul class="elementor-icon-list-items elementor-inline-items">
                                            <li class="elementor-icon-list-item elementor-inline-item">
                                                <a href="https://mainlandsolar.com/privacy-policy">

                                                    <span class="elementor-icon-list-text">Privacy Policy</span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item elementor-inline-item">
                                                <a href="https://mainlandsolar.com/term-and-conditions">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-slash"></i>						</span>
                                                    <span class="elementor-icon-list-text">Terms & Conditions</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>		</footer>
</div><!-- #page -->
<div class="account-wrap d-none">
    <div class="account-inner dashboard">
        <ul class="account-dashboard">
            <li>
                <a href="https://mainlandsolar.com/my-account/" title="Dashboard">Dashboard</a>
            </li>
            <li>
                <a href="https://mainlandsolar.com/my-account/orders/" title="Orders">Orders</a>
            </li>
            <li>
                <a href="https://mainlandsolar.com/my-account/downloads/" title="Downloads">Downloads</a>
            </li>
            <li>
                <a href="https://mainlandsolar.com/my-account/edit-address/" title="Edit Address">Edit Address</a>
            </li>
            <li>
                <a href="https://mainlandsolar.com/my-account/edit-account/" title="Account Details">Account Details</a>
            </li>
            <li>
                <a title="Log out" class="tips" href="https://mainlandsolar.com/wp-login.php?action=logout&#038;redirect_to=https%3A%2F%2Fmainlandsolar.com&#038;_wpnonce=d332aeedfe">Log Out</a>
            </li>
        </ul>
    </div>
</div>
<div class="technocy-mobile-nav">
    <div class="menu-scroll-mobile">
        <a href="#" class="mobile-nav-close"><i class="technocy-icon-times"></i></a>
        <div class="mobile-nav-tabs">
            <ul>
                <li class="mobile-tab-title mobile-pages-title active" data-menu="pages">
                    <span>Main menu</span>
                </li>
            </ul>
        </div>
        <nav class="mobile-menu-tab mobile-navigation mobile-pages-menu active"
             aria-label="Mobile Navigation">
            <div class="handheld-navigation"><ul id="menu-main-menu" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-8404"><a href="https://mainlandsolar.com/">Home</a></li>
                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6902"><a href="https://mainlandsolar.com/about/">About Us</a></li>
                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8690"><a href="https://mainlandsolar.com/services/">Services</a></li>
                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8525"><a href="https://mainlandsolar.com/solar-hub/">Solar Hub</a></li>
                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8520"><a href="https://mainlandsolar.com/news-and-updates/">News &#038; Updates</a></li>
                    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6903"><a href="https://mainlandsolar.com/contact/">Contact Us</a></li>
                </ul></div>        </nav>
        <nav class="mobile-menu-tab mobile-navigation-categories mobile-categories-menu"
             aria-label="Mobile Navigation">
            <div class="menu"><ul>
                    <li ><a href="https://mainlandsolar.com/">Home</a></li><li class="page_item page-item-1738"><a href="https://mainlandsolar.com/about/">About</a></li>
                    <li class="page_item page-item-9004"><a href="https://mainlandsolar.com/cancel-appointment/">Cancel page</a></li>
                    <li class="page_item page-item-9005"><a href="https://mainlandsolar.com/cancel-payment/">Cancel Payment page</a></li>
                    <li class="page_item page-item-11"><a href="https://mainlandsolar.com/cart/">Cart</a></li>
                    <li class="page_item page-item-8381"><a href="https://mainlandsolar.com/cart-2/">Cart</a></li>
                    <li class="page_item page-item-12"><a href="https://mainlandsolar.com/checkout/">Checkout</a></li>
                    <li class="page_item page-item-8382"><a href="https://mainlandsolar.com/checkout-2/">Checkout</a></li>
                    <li class="page_item page-item-838"><a href="https://mainlandsolar.com/contact/">Contact</a></li>
                    <li class="page_item page-item-8385"><a href="https://mainlandsolar.com/demo/">demo</a></li>
                    <li class="page_item page-item-1570"><a href="https://mainlandsolar.com/faq/">Frequently Asked Questions</a></li>
                    <li class="page_item page-item-5934"><a href="https://mainlandsolar.com/shop-hot-deals/">Hot Deals</a></li>
                    <li class="page_item page-item-1631"><a href="https://mainlandsolar.com/icon/">icon</a></li>
                    <li class="page_item page-item-5749"><a href="https://mainlandsolar.com/landingpage/">Landingpage</a></li>
                    <li class="page_item page-item-8899"><a href="https://mainlandsolar.com/term-and-conditions/">Mainland Solar Terms and Conditions</a></li>
                    <li class="page_item page-item-13"><a href="https://mainlandsolar.com/my-account/">My account</a></li>
                    <li class="page_item page-item-8383"><a href="https://mainlandsolar.com/my-account-2/">My account</a></li>
                    <li class="page_item page-item-386"><a href="https://mainlandsolar.com/news-and-updates/">News &#038; Updates</a></li>
                    <li class="page_item page-item-3"><a href="https://mainlandsolar.com/privacy-policy-2/">Privacy Policy</a></li>
                    <li class="page_item page-item-2"><a href="https://mainlandsolar.com/sample-page/">Sample Page</a></li>
                    <li class="page_item page-item-8378"><a href="https://mainlandsolar.com/sample-page-2/">Sample Page</a></li>
                    <li class="page_item page-item-8684"><a href="https://mainlandsolar.com/services/">Services</a></li>
                    <li class="page_item page-item-10"><a href="https://mainlandsolar.com/shop/">Shop</a></li>
                    <li class="page_item page-item-8380"><a href="https://mainlandsolar.com/shop-2/">Shop</a></li>
                    <li class="page_item page-item-8937 current_page_item"><a href="https://mainlandsolar.com/solar-audit/" aria-current="page">Solar Audit</a></li>
                    <li class="page_item page-item-8521"><a href="https://mainlandsolar.com/solar-hub/">Solar Hub</a></li>
                    <li class="page_item page-item-8931"><a href="https://mainlandsolar.com/solar-installation/">Solar Installation</a></li>
                    <li class="page_item page-item-9003"><a href="https://mainlandsolar.com/thank-you/">Thank you page</a></li>
                    <li class="page_item page-item-15"><a href="https://mainlandsolar.com/wishlist/">Wishlist</a></li>
                    <li class="page_item page-item-8384"><a href="https://mainlandsolar.com/wishlist-2/">Wishlist</a></li>
                </ul></div>
        </nav>
    </div>
</div>
<div class="technocy-overlay"></div>

<script type="text/javascript">
    window.RS_MODULES = window.RS_MODULES || {};
    window.RS_MODULES.modules = window.RS_MODULES.modules || {};
    window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
    window.RS_MODULES.defered = true;
    window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
    window.RS_MODULES.type = 'compiled';
</script>
<div class="site-search-popup">
    <div class="site-search-popup-wrap">
        <a href="#" class="site-search-popup-close"><i class="technocy-icon-times-circle"></i></a>
        <div class="site-search ajax-search">
            <div class="widget woocommerce widget_product_search">
                <div class="ajax-search-result d-none"></div>
                <form role="search" method="get" class="woocommerce-product-search" action="https://mainlandsolar.com/">
                    <label class="screen-reader-text" for="woocommerce-product-search-field-1">Search for:</label>
                    <input type="search" id="woocommerce-product-search-field-1" class="search-field" placeholder="Search products&hellip;" autocomplete="off" value="" name="s"/>
                    <button type="submit" value="Search">Search</button>
                    <input type="hidden" name="post_type" value="product"/>
                    <div class="search-by-category input-dropdown">
                        <div class="input-dropdown-inner technocy-scroll-content">
                            <!--                    <input type="hidden" name="product_cat" value="0">-->
                            <a href="#" data-val="0"><span>All category</span></a>
                            <select  name='product_cat' id='product_cat0' class='dropdown_product_cat_ajax' >
                                <option value='' selected='selected'>All category</option>
                                <option class="level-0" value="batteries">Batteries</option>
                                <option class="level-0" value="charge-controllers">Charge Controllers</option>
                                <option class="level-0" value="inverters">Inverters</option>
                                <option class="level-0" value="solar-panels">Solar Panels</option>
                            </select>
                            <div class="list-wrapper technocy-scroll">
                                <ul class="technocy-scroll-content">
                                    <li class="d-none">
                                        <a href="#" data-val="0">All category</a></li>
                                    <li class="cat-item cat-item-36"><a class="pf-value" href="https://mainlandsolar.com/product-category/batteries/" data-val="batteries" data-title="Batteries" >Batteries</a>
                                    </li>
                                    <li class="cat-item cat-item-46"><a class="pf-value" href="https://mainlandsolar.com/product-category/charge-controllers/" data-val="charge-controllers" data-title="Charge Controllers" >Charge Controllers</a>
                                    </li>
                                    <li class="cat-item cat-item-35"><a class="pf-value" href="https://mainlandsolar.com/product-category/inverters/" data-val="inverters" data-title="Inverters" >Inverters</a>
                                    </li>
                                    <li class="cat-item cat-item-15"><a class="pf-value" href="https://mainlandsolar.com/product-category/solar-panels/" data-val="solar-panels" data-title="Solar Panels" >Solar Panels</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="site-search-popup-overlay"></div>
<script>
    (function() {function maybePrefixUrlField() {
        if (this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
            this.value = "http://" + this.value;
        }
    }

        var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
        if (urlFields) {
            for (var j=0; j < urlFields.length; j++) {
                urlFields[j].addEventListener('blur', maybePrefixUrlField);
            }
        }
    })();
</script>
<div class="woosc-popup woosc-search">
    <div class="woosc-popup-inner">
        <div class="woosc-popup-content">
            <div class="woosc-popup-content-inner">
                <div class="woosc-popup-close"></div>
                <div class="woosc-search-input">
                    <input type="search" id="woosc_search_input"
                           placeholder="Type any keyword to search..."/>
                </div>
                <div class="woosc-search-result"></div>
            </div>
        </div>
    </div>
</div>
<div class="woosc-popup woosc-settings">
    <div class="woosc-popup-inner">
        <div class="woosc-popup-content">
            <div class="woosc-popup-content-inner">
                <div class="woosc-popup-close"></div>
                Select the fields to be shown. Others will be hidden. Drag and drop to rearrange the order.                                        <ul class="woosc-settings-fields">
                    <li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="image" checked/><span class="label">Image</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="sku" checked/><span class="label">SKU</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="rating" checked/><span class="label">Rating</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="price" checked/><span class="label">Price</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="stock" checked/><span class="label">Stock</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="availability" checked/><span class="label">Availability</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="add_to_cart" checked/><span class="label">Add to cart</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="description" checked/><span class="label">Description</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="content" checked/><span class="label">Content</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="weight" checked/><span class="label">Weight</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="dimensions" checked/><span class="label">Dimensions</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="additional" checked/><span class="label">Additional information</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="attributes" checked/><span class="label">Attributes</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="custom_attributes" checked/><span class="label">Custom attributes</span></li><li class="woosc-settings-field-li"><input type="checkbox" class="woosc-settings-field" value="custom_fields" checked/><span class="label">Custom fields</span></li>                                        </ul>
            </div>
        </div>
    </div>
</div>

<div id="woosc-area" class="woosc-area woosc-bar-bottom woosc-bar-right woosc-bar-click-outside-yes woosc-hide-checkout"data-bg-color="#292a30" data-btn-color="#00a0d2">
    <div class="woosc-inner">
        <div class="woosc-table">
            <div class="woosc-table-inner">
                <a href="javascript:void(0);" id="woosc-table-close"
                   class="woosc-table-close hint--left"
                   aria-label="Close"><span
                        class="woosc-table-close-icon"></span></a>
                <div class="woosc-table-items"></div>
            </div>
        </div>
        <div class="woosc-bar ">
            <div class="woosc-bar-notice">
                Click outside to hide the compare bar                                    </div>
            <a href="javascript:void(0);" class="woosc-bar-settings hint--top"
               aria-label="Select fields"></a>
            <a href="javascript:void(0);" class="woosc-bar-search hint--top"
               aria-label="Add product"></a>
            <div class="woosc-bar-items"></div>
            <div class="woosc-bar-btn woosc-bar-btn-text">
                <div class="woosc-bar-btn-icon-wrapper">
                    <div class="woosc-bar-btn-icon-inner"><span></span><span></span><span></span>
                    </div>
                </div>
                Compare                                </div>
        </div>
    </div>
</div>
<div id="woosw-area" class="woosw-area">
    <div class="woosw-inner">
        <div class="woosw-content">
            <div class="woosw-content-top">
                Wishlist<span class="woosw-count">0</span>
                <span class="woosw-close"></span>
            </div>
            <div class="woosw-content-mid"></div>
            <div class="woosw-content-bot">
                <div class="woosw-content-bot-inner">
                    <a class="woosw-page" href="https://mainlandsolar.com/wishlist/">Open wishlist page</a>
                    <span class="woosw-continue" data-url="">Continue shopping<span>
                </div>
                <div class="woosw-notice"></div>
            </div>
        </div>
    </div>
</div>

<script type="application/ld+json">{"@context":"https:\/\/schema.org\/","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"item":{"name":"Home Page","@id":"https:\/\/mainlandsolar.com"}},{"@type":"ListItem","position":2,"item":{"name":"Solar Audit","@id":"https:\/\/mainlandsolar.com\/solar-audit\/"}}]}</script>
<script type="text/template" id="tmpl-elementor-templates-modal__header">
    <div class="elementor-templates-modal__header__logo-area"></div>
    <div class="elementor-templates-modal__header__menu-area"></div>
    <div class="elementor-templates-modal__header__items-area">
        <# if ( closeType ) { #>
        <div class="elementor-templates-modal__header__close elementor-templates-modal__header__close--{{{ closeType }}} elementor-templates-modal__header__item">
            <# if ( 'skip' === closeType ) { #>
            <span>Skip</span>
            <# } #>
            <i class="eicon-close" aria-hidden="true" title="Close"></i>
            <span class="elementor-screen-only">Close</span>
        </div>
        <# } #>
        <div id="elementor-template-library-header-tools"></div>
    </div>
</script>
<script type="text/template" id="tmpl-elementor-templates-modal__header__logo">
    <span class="elementor-templates-modal__header__logo__icon-wrapper e-logo-wrapper">
		<i class="eicon-elementor"></i>
	</span>
    <span class="elementor-templates-modal__header__logo__title">{{{ title }}}</span>
</script>
<script type="text/template" id="tmpl-elementor-finder">
    <div id="elementor-finder__search">
        <i class="eicon-search"></i>
        <input id="elementor-finder__search__input" placeholder="Type to find anything in Elementor" autocomplete="off">
    </div>
    <div id="elementor-finder__content"></div>
</script>
<script type="text/template" id="tmpl-elementor-finder-results-container">
    <div id="elementor-finder__no-results">No Results Found</div>
    <div id="elementor-finder__results"></div>
</script>
<script type="text/template" id="tmpl-elementor-finder__results__category">
    <div class="elementor-finder__results__category__title">{{{ title }}}</div>
    <div class="elementor-finder__results__category__items"></div>
</script>
<script type="text/template" id="tmpl-elementor-finder__results__item">
    <a href="{{ url }}" class="elementor-finder__results__item__link">
        <div class="elementor-finder__results__item__icon">
            <i class="eicon-{{{ icon }}}"></i>
        </div>
        <div class="elementor-finder__results__item__title">{{{ title }}}</div>
        <# if ( description ) { #>
        <div class="elementor-finder__results__item__description">- {{{ description }}}</div>
        <# } #>
    </a>
    <# if ( actions.length ) { #>
    <div class="elementor-finder__results__item__actions">
        <# jQuery.each( actions, function() { #>
        <a class="elementor-finder__results__item__action elementor-finder__results__item__action--{{ this.name }}" href="{{ this.url }}" target="_blank">
            <i class="eicon-{{{ this.icon }}}"></i>
        </a>
        <# } ); #>
    </div>
    <# } #>
</script>
<script type="text/javascript">
    (function () {
        var c = document.body.className;
        c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
        document.body.className = c;
    })();
</script>
<div class="site-header-cart-side">
    <div class="cart-side-heading">
        <span class="cart-side-title">Shopping cart</span>
        <a href="#" class="close-cart-side">close</a></div>
    <div class="widget woocommerce widget_shopping_cart"><div class="widget_shopping_cart_content"></div></div>            </div>
<div class="cart-side-overlay"></div>
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://mainlandsolar.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.5.8' media='all' />
<style id='rs-plugin-settings-inline-css'>
    #rs-demo-id {}
</style>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.7' id='regenerator-runtime-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script id='contact-form-7-js-extra'>
    var wpcf7 = {"api":{"root":"https:\/\/mainlandsolar.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.4' id='contact-form-7-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.5.8' defer async id='tp-tools-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.5.8' defer async id='revmin-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.6.2.0' id='jquery-blockui-js'></script>
<script id='wc-add-to-cart-js-extra'>
    var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"","cart_url":"https:\/\/mainlandsolar.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=6.2.0' id='wc-add-to-cart-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.6.2.0' id='js-cookie-js'></script>
<script id='woocommerce-js-extra'>
    var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=6.2.0' id='woocommerce-js'></script>
<script id='wc-cart-fragments-js-extra'>
    var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_0b0c4cb16c3c9367c2aeff1b5eac6191","fragment_name":"wc_fragments_0b0c4cb16c3c9367c2aeff1b5eac6191","request_timeout":"5000"};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=6.2.0' id='wc-cart-fragments-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/woo-smart-compare/assets/libs/table-head-fixer/table-head-fixer.js?ver=4.2.5' id='table-head-fixer-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/woo-smart-compare/assets/libs/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js?ver=4.2.5' id='perfect-scrollbar-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/jquery/ui/mouse.min.js?ver=1.12.1' id='jquery-ui-mouse-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/jquery/ui/sortable.min.js?ver=1.12.1' id='jquery-ui-sortable-js'></script>
<script id='woosc-frontend-js-extra'>
    var woosc_vars = {"ajaxurl":"https:\/\/mainlandsolar.com\/wp-admin\/admin-ajax.php","user_id":"b4f377609b848a77b18f33dfd252cb09","page_url":"#","open_button":"","open_button_action":"open_popup","menu_action":"open_popup","open_table":"yes","open_bar":"no","bar_bubble":"no","click_again":"no","hide_empty":"no","click_outside":"yes","freeze_column":"yes","freeze_row":"yes","scrollbar":"yes","limit":"100","button_text_change":"yes","remove_all":"Do you want to remove all products from the compare?","limit_notice":"You can add a maximum of {limit} products to the compare table.","button_text":"Compare","button_text_added":"Compare","nonce":"41e3ab7887"};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/woo-smart-compare/assets/js/frontend.js?ver=4.2.5' id='woosc-frontend-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/underscore.min.js?ver=1.13.1' id='underscore-js'></script>
<script id='wp-util-js-extra'>
    var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
</script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/wp-util.min.js?ver=5.8.3' id='wp-util-js'></script>
<script id='wc-add-to-cart-variation-js-extra'>
    var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=6.2.0' id='wc-add-to-cart-variation-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/vendor/slick.min.js?ver=1.1.0' id='slick-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/vendor/jquery.magnific-popup.min.js?ver=1.1.0' id='magnific-popup-js'></script>
<script id='woosq-frontend-js-extra'>
    var woosq_vars = {"ajax_url":"https:\/\/mainlandsolar.com\/wp-admin\/admin-ajax.php","effect":"mfp-3d-unfold","scrollbar":"yes","hashchange":"no","cart_redirect":"no","cart_url":"https:\/\/mainlandsolar.com\/cart\/","close":"Close (Esc)","next":"Next (Right arrow key)","prev":"Previous (Left arrow key)","is_rtl":""};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/woo-smart-quick-view/assets/js/frontend.js?ver=2.8.3' id='woosq-frontend-js'></script>
<script id='woosw-frontend-js-extra'>
    var woosw_vars = {"ajax_url":"https:\/\/mainlandsolar.com\/wp-admin\/admin-ajax.php","menu_action":"open_page","perfect_scrollbar":"yes","wishlist_url":"https:\/\/mainlandsolar.com\/wishlist\/","button_action":"list","button_action_added":"popup","empty_confirm":"Are you sure? This cannot be undone.","copied_text":"Copied the wishlist link:","menu_text":"Wishlist","button_text":"Add to wishlist","button_text_added":"Browse wishlist"};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/woo-smart-wishlist/assets/js/frontend.js?ver=2.9.4' id='woosw-frontend-js'></script>
<script id='technocy-theme-js-extra'>
    var technocyAjax = {"ajaxurl":"https:\/\/mainlandsolar.com\/wp-admin\/admin-ajax.php"};
</script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/frontend/main.js?ver=1.1.0' id='technocy-theme-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/skip-link-focus-fix.min.js?ver=20130115' id='technocy-skip-link-focus-fix-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/frontend/search-popup.js?ver=1.1.0' id='technocy-search-popup-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/frontend/text-editor.js?ver=1.1.0' id='technocy-text-editor-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/frontend/nav-mobile.js?ver=1.1.0' id='technocy-nav-mobile-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/inc/megamenu/assets/js/frontend.js?ver=1.1.0' id='technocy-megamenu-frontend-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/jquery/ui/draggable.min.js?ver=1.12.1' id='jquery-ui-draggable-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/backbone.min.js?ver=1.4.0' id='backbone-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/lib/backbone/backbone.marionette.min.js?ver=2.4.5.e1' id='backbone-marionette-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/lib/backbone/backbone.radio.min.js?ver=1.0.4' id='backbone-radio-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/js/common-modules.min.js?ver=3.5.5' id='elementor-common-modules-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.9.0' id='elementor-dialog-js'></script>
<script id='wp-api-request-js-extra'>
    var wpApiSettings = {"root":"https:\/\/mainlandsolar.com\/wp-json\/","nonce":"49bfac14af","versionString":"wp\/v2\/"};
</script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/api-request.min.js?ver=5.8.3' id='wp-api-request-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/dist/hooks.min.js?ver=a7edae857aab69d69fa10d5aef23a5de' id='wp-hooks-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/dist/i18n.min.js?ver=5f1269854226b4dd90450db411a12b79' id='wp-i18n-js'></script>
<script id='wp-i18n-js-after'>
    wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script id='elementor-common-js-translations'>
    ( function( domain, translations ) {
        var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
        localeData[""].domain = domain;
        wp.i18n.setLocaleData( localeData, domain );
    } )( "elementor", { "locale_data": { "messages": { "": {} } } } );
</script>
<script id='elementor-common-js-before'>
    var elementorCommonConfig = {"version":"3.5.5","isRTL":false,"isDebug":false,"isElementorDebug":false,"activeModules":["ajax","finder","connect"],"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"a11y_improvements":true,"e_import_export":true,"additional_custom_breakpoints":true,"e_hidden_wordpress_widgets":true,"landing-pages":true,"elements-color-picker":true,"favorite-widgets":true,"admin-top-bar":true},"urls":{"assets":"https:\/\/mainlandsolar.com\/wp-content\/plugins\/elementor\/assets\/","rest":"https:\/\/mainlandsolar.com\/wp-json\/"},"ajax":{"url":"https:\/\/mainlandsolar.com\/wp-admin\/admin-ajax.php","nonce":"8542b60f80"},"finder":{"data":{"edit":{"title":"Edit","dynamic":true,"name":"edit"},"general":{"title":"General","dynamic":false,"items":{"saved-templates":{"title":"Saved Templates","icon":"library-save","url":"https:\/\/mainlandsolar.com\/wp-admin\/edit.php?post_type=elementor_library&tabs_group=library","keywords":["template","section","page","library"]},"system-info":{"title":"System Info","icon":"info-circle-o","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-system-info","keywords":["system","info","environment","elementor"]},"role-manager":{"title":"Role Manager","icon":"person","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-role-manager","keywords":["role","manager","user","elementor"]},"knowledge-base":{"title":"Knowledge Base","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=go_knowledge_base_site","keywords":["help","knowledge","docs","elementor"]},"theme-builder":{"title":"Theme Builder","icon":"library-save","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-app&ver=3.5.5#site-editor\/promotion","keywords":["template","header","footer","single","archive","search","404","library"]}},"name":"general"},"create":{"title":"Create","dynamic":false,"items":{"page":{"title":"Add New Page Template","icon":"plus-circle-o","url":"https:\/\/mainlandsolar.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=elementor_library&template_type=page&_wpnonce=dd94216d85","keywords":["Add New Page Template","post","page","template","new","create"]},"section":{"title":"Add New Section","icon":"plus-circle-o","url":"https:\/\/mainlandsolar.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=elementor_library&template_type=section&_wpnonce=dd94216d85","keywords":["Add New Section","post","page","template","new","create"]},"wp-post":{"title":"Add New Post","icon":"plus-circle-o","url":"https:\/\/mainlandsolar.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=post&template_type=wp-post&_wpnonce=dd94216d85","keywords":["Add New Post","post","page","template","new","create"]},"wp-page":{"title":"Add New Page","icon":"plus-circle-o","url":"https:\/\/mainlandsolar.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=page&template_type=wp-page&_wpnonce=dd94216d85","keywords":["Add New Page","post","page","template","new","create"]},"landing-page":{"title":"Add New Landing Page","icon":"plus-circle-o","url":"https:\/\/mainlandsolar.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=e-landing-page&template_type=landing-page&_wpnonce=dd94216d85#library","keywords":["Add New Landing Page","post","page","template","new","create"]},"elementor-hf":{"title":"Add New Elementor Header & Footer Builder","icon":"plus-circle-o","url":"https:\/\/mainlandsolar.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=elementor-hf&_wpnonce=dd94216d85","keywords":["Add New Elementor Header & Footer Builder","post","page","template","new","create"]},"technocy-breadcrumb":{"title":"Add New Breadcrumb","icon":"plus-circle-o","url":"https:\/\/mainlandsolar.com\/wp-admin\/edit.php?action=elementor_new_post&post_type=technocy-breadcrumb&_wpnonce=dd94216d85","keywords":["Add New Breadcrumb","post","page","template","new","create"]}},"name":"create"},"site":{"title":"Site","dynamic":false,"items":{"homepage":{"title":"Homepage","url":"https:\/\/mainlandsolar.com","icon":"home-heart","keywords":["home","page"]},"wordpress-dashboard":{"title":"Dashboard","icon":"dashboard","url":"https:\/\/mainlandsolar.com\/wp-admin\/","keywords":["dashboard","wordpress"]},"wordpress-menus":{"title":"Menus","icon":"wordpress","url":"https:\/\/mainlandsolar.com\/wp-admin\/nav-menus.php","keywords":["menu","wordpress"]},"wordpress-themes":{"title":"Themes","icon":"wordpress","url":"https:\/\/mainlandsolar.com\/wp-admin\/themes.php","keywords":["themes","wordpress"]},"wordpress-customizer":{"title":"Customizer","icon":"wordpress","url":"https:\/\/mainlandsolar.com\/wp-admin\/customize.php","keywords":["customizer","wordpress"]},"wordpress-plugins":{"title":"Plugins","icon":"wordpress","url":"https:\/\/mainlandsolar.com\/wp-admin\/plugins.php","keywords":["plugins","wordpress"]},"wordpress-users":{"title":"Users","icon":"wordpress","url":"https:\/\/mainlandsolar.com\/wp-admin\/users.php","keywords":["users","profile","wordpress"]}},"name":"site"},"settings":{"title":"Settings","dynamic":false,"items":{"general-settings":{"title":"General Settings","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor","keywords":["general","settings","elementor"]},"advanced":{"title":"Advanced","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor#tab-advanced","keywords":["advanced","settings","elementor"]},"experiments":{"title":"Experiments","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor#tab-experiments","keywords":["settings","elementor","experiments"]}},"name":"settings"},"tools":{"title":"Tools","dynamic":false,"items":{"tools":{"title":"Tools","icon":"tools","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-tools","keywords":["tools","regenerate css","safe mode","debug bar","sync library","elementor"]},"replace-url":{"title":"Replace URL","icon":"tools","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-tools#tab-replace_url","keywords":["tools","replace url","domain","elementor"]},"maintenance-mode":{"title":"Maintenance Mode","icon":"tools","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-tools#tab-maintenance_mode","keywords":["tools","maintenance","coming soon","elementor"]},"version-control":{"title":"Version Control","icon":"time-line","url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-tools#tab-versions","keywords":["tools","version","control","rollback","beta","elementor"]}},"name":"tools"}}},"connect":[]};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/js/common.min.js?ver=3.5.5' id='elementor-common-js'></script>
<script id='elementor-app-loader-js-before'>
    var elementorAppConfig = {"menu_url":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-app&ver=3.5.5#site-editor\/promotion","assets_url":"https:\/\/mainlandsolar.com\/wp-content\/plugins\/elementor\/assets\/","return_url":"https:\/\/mainlandsolar.com\/","hasPro":false,"admin_url":"https:\/\/mainlandsolar.com\/wp-admin\/","login_url":"https:\/\/mainlandsolar.com\/wp-login.php","site-editor":[],"import-export":[],"kit-library":[]};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/js/app-loader.min.js?ver=3.5.5' id='elementor-app-loader-js'></script>
<script id='woo-variation-swatches-js-extra'>
    var woo_variation_swatches_options = {"is_product_page":"","show_variation_label":"1","variation_label_separator":":","wvs_nonce":"e4996f9bf7"};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/woo-variation-swatches/assets/js/frontend.min.js?ver=1.1.19' id='woo-variation-swatches-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/woocommerce/header-cart.min.js?ver=1.1.0' id='technocy-header-cart-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/tooltipster.bundle.js?ver=1.1.0' id='tooltipster-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/woocommerce/product-ajax-search.min.js?ver=1.1.0' id='technocy-products-ajax-search-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/woocommerce/main.min.js?ver=1.1.0' id='technocy-products-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/woocommerce/quantity.min.js?ver=1.1.0' id='technocy-input-quantity-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/woocommerce/cart-canvas.min.js?ver=1.1.0' id='technocy-cart-canvas-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.5.5' id='elementor-webpack-runtime-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.5.5' id='elementor-frontend-modules-js'></script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script id='elementor-frontend-js-before'>
    var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Extra","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Extra","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.5.5","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"a11y_improvements":true,"e_import_export":true,"additional_custom_breakpoints":true,"e_hidden_wordpress_widgets":true,"landing-pages":true,"elements-color-picker":true,"favorite-widgets":true,"admin-top-bar":true},"urls":{"assets":"https:\/\/mainlandsolar.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":8937,"title":"Solar%20Audit%20%E2%80%93%20Mainlandsolar","excerpt":"","featuredImage":false},"user":{"roles":["administrator"]}};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.5.5' id='elementor-frontend-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/elementor/header-group.js?ver=1.1.0' id='technocy-elementor-header-group-js'></script>
<script defer src='https://mainlandsolar.com/wp-content/plugins/mailchimp-for-wp/assets/js/forms.js?ver=4.8.6' id='mc4wp-forms-api-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/elementor-frontend.js?ver=1.1.0' id='technocy-elementor-frontend-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/vendor/jquery.sticky.js?ver=1.1.0' id='elementor-sticky-js'></script>
<script src='https://mainlandsolar.com/wp-content/themes/technocy/assets/js/vendor/sticky.min.js?ver=1.1.0' id='technocy-elementor-sticky-js'></script>
<script id='elementor-admin-bar-js-before'>
    var elementorAdminBarConfig = {"elementor_edit_page":{"id":"elementor_edit_page","title":"Edit with Elementor","href":"https:\/\/mainlandsolar.com\/wp-admin\/post.php?post=8937&action=elementor","children":{"855":{"id":"elementor_edit_doc_855","title":"Header 1","sub_title":"Post","href":"https:\/\/mainlandsolar.com\/wp-admin\/post.php?post=855&action=elementor"},"3909":{"id":"elementor_edit_doc_3909","title":"Breadcrumb","sub_title":"Post","href":"https:\/\/mainlandsolar.com\/wp-admin\/post.php?post=3909&action=elementor"},"3091":{"id":"elementor_edit_doc_3091","title":"Footer bar","sub_title":"Post","href":"https:\/\/mainlandsolar.com\/wp-admin\/post.php?post=3091&action=elementor"},"860":{"id":"elementor_edit_doc_860","title":"Footer 5","sub_title":"Post","href":"https:\/\/mainlandsolar.com\/wp-admin\/post.php?post=860&action=elementor"},"3910":{"id":"elementor_site_settings","title":"Site Settings","sub_title":"Site","href":"https:\/\/mainlandsolar.com\/wp-admin\/post.php?post=8937&action=elementor#e:run:panel\/global\/open","class":"elementor-site-settings","parent_class":"elementor-second-section"},"3911":{"id":"elementor_app_site_editor","title":"Theme Builder","sub_title":"Site","href":"https:\/\/mainlandsolar.com\/wp-admin\/admin.php?page=elementor-app&ver=3.5.5#site-editor\/promotion","class":"elementor-app-link","parent_class":"elementor-second-section"}}}};
</script>
<script src='https://mainlandsolar.com/wp-content/plugins/elementor/assets/js/elementor-admin-bar.min.js?ver=3.5.5' id='elementor-admin-bar-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/hoverintent-js.min.js?ver=2.2.1' id='hoverintent-js-js'></script>
<script data-cfasync="false" src='https://mainlandsolar.com/wp-includes/js/admin-bar.min.js?ver=5.8.3' id='admin-bar-js'></script>
<script type="text/javascript">
    function rs_adminBarToolBarTopFunction() {
        if(jQuery('#wp-admin-bar-revslider-default').length > 0 && jQuery('rs-module-wrap').length > 0){
            var aliases = new Array();
            jQuery('rs-module-wrap').each(function(){
                aliases.push(jQuery(this).data('alias'));
            });

            if(aliases.length > 0){
                jQuery('#wp-admin-bar-revslider-default li').each(function(){
                    var li = jQuery(this),
                        t = li.find('.ab-item .rs-label').data('alias'); //text()
                    t = t!==undefined && t!==null ? t.trim() : t;
                    if(jQuery.inArray(t,aliases)!=-1){
                    }else{
                        li.remove();
                    }
                });
            }
        }else{
            jQuery('#wp-admin-bar-revslider').remove();
        }
    }
    var adminBarLoaded_once = false
    if (document.readyState === "loading")
        document.addEventListener('readystatechange',function(){
            if ((document.readyState === "interactive" || document.readyState === "complete") && !adminBarLoaded_once) {
                adminBarLoaded_once = true;
                rs_adminBarToolBarTopFunction()
            }
        });
    else {
        adminBarLoaded_once = true;
        rs_adminBarToolBarTopFunction();
    }
</script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/main.js"></script>
<script src="js/customer-reducer.js"></script>
<script src="js/jquery-confirm.min.js"></script>
</body>
</html>