
<div class="clearfix"></div>
<!-- footer start-->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 footer-copyright">
                <p class="mb-0">Copyright <?php echo date('Y'); ?> © Mainlandsolar In Lagos All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>
<!-- footer end-->
</div>

</div>
<script src="./assets/js/jquery-3.3.1.min.js"></script>
<script src="./assets/js/popper.min.js"></script>
<script src="./assets/js/bootstrap.js"></script>
<script src="./assets/js/icons/feather-icon/feather.min.js"></script>
<script src="./assets/js/icons/feather-icon/feather-icon.js"></script>

<script src="./assets/js/serialObject.js"></script>
<script src="./assets/js/jquery.validate.min.js"></script>

<script src="./assets/js/jquery.dataTables.min.js"></script>

<script src="./assets/js/sidebar-menu.js"></script>

<script src="./assets/js/counter/jquery.waypoints.min.js"></script>
<script src="./assets/js/counter/jquery.counterup.min.js"></script>
<script src="./assets/js/counter/counter-custom.js"></script>

<!--dashboard custom js-->
<script src="./assets/js/admin-script.js"></script>
<script src="./assets/js/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>


</body>
</html>
